LOCALDIR="$(cd $(dirname $0); pwd)"
bin=$LOCALDIR/bin
updatev=$(curl -s https://gitee.com/ChinaXB_admin/romtool-windowd/raw/master/bin/version)
tikver=$(cat $bin/version)

if [ $updatev -gt $tikver ]; then
	echo -e "\e[1;32m 检测到更新：[$updatev]...\e[0m"
else
    echo -e "\e[1;32m 未检测到更新：[$tikver]...\e[0m"
fi
