#!/system/bin/sh

LOCALDIR=$(cd "$(dirname "$0")";pwd)
home=$LOCALDIR/rom

rm -rf $home/image/*
rm -rf $home/out/*
mkdir -p $home/out/config
mkdir -p $home/out/image
rm -rf $home/tmp/*