#!/system/bin/sh
LOCALDIR="$(cd $(dirname $0); pwd)"

echo -e "\033[2;32m 正在配置环境，请稍后！\033[0m"

apt="python3 python3-pip curl default-jre bc android-sdk-libsparse-utils aria2 openjdk-11-jre zip p7zip-full"
PIP=https://pypi.tuna.tsinghua.edu.cn/simple/

sudo apt install $apt -y
pip install --upgrade pip -i $PIP
pip install pycryptodome -i $PIP
pip install docopt -i $PIP
pip install requests -i $PIP
pip install beautifulsoup4 -i $PIP
pip install --ignore-installed pyyaml -i $PIP
if [ -e ./rom ];then
 echo "检测到ROM文件夹，跳过创建该文件夹"
else
 echo "未检测到ROM文件夹，正在创建ROM文件夹"
 sudo mkdir ./rom
fi
if [ -e ./rom/tmp ];then
 echo "检测到输出文件夹，跳过创建该文件夹"
else
 echo "未检测到输出文件夹，正在创建输出文件夹"
 sudo mkdir ./rom/tmp
fi
if [ -e ./rom/out ];then
 echo "检测到out文件夹，跳过创建该文件夹"
else
 echo "未检测到out文件夹，正在创建out文件夹"
 sudo mkdir ./rom/out
fi
if [ -e ./rom/out/config ];then
 echo "检测到配置文件文件夹，跳过创建该文件夹"
else
 echo "未检测到配置文件文件夹，正在创建配置文件文件夹"
 sudo mkdir ./rom/out/config
fi
if [ -e ./rom/image ];then
 echo "检测到Image文件夹，跳过创建该文件夹"
else
 echo "未检测到Image文件夹，正在创建Image文件夹"
 sudo mkdir ./rom/image
fi
if [ -e ./rom/out/image ];then
 echo "检测到输出Image文件夹，跳过创建该文件夹"
else
 echo "未检测到输出Image文件夹，正在创建输出Image文件夹"
 sudo mkdir ./rom/out/image
fi
sudo chmod -R 777 $LOCALDIR
echo -e "\033[2;33m环境配置完成\033[0m"